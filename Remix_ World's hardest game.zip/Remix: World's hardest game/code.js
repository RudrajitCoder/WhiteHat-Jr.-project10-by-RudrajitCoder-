var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["36f58a95-8579-4b60-8ca1-64255133a1f4","2bada650-7f0c-419f-9b28-24d2217c8cf6","ebcb7aa7-69ca-4869-8fff-5782fc2264b0","ca6699fc-18d2-4c30-a81c-1bfe4a2eb9a7","cbb8a44d-46c1-4d9b-8b54-08ef261c3147","d561f458-aaa9-4858-8b54-4baa44b6a123","680a368f-d75b-471d-8afc-777140ac313e","12216abd-aa32-4566-8df7-e300430286c9","afbeb2a7-9a12-4fdb-adb7-7b22e7bceff4"],"propsByKey":{"36f58a95-8579-4b60-8ca1-64255133a1f4":{"name":"atb","sourceUrl":"assets/v3/animations/COur4Yk9wN67PEowD8fbUzrmrNA6DDoR_Dft2qGzhHU/36f58a95-8579-4b60-8ca1-64255133a1f4.png","frameSize":{"x":349,"y":144},"frameCount":1,"looping":true,"frameDelay":4,"version":"8UbsLoe7k0MvwDdqGVf52Oh9URClqStn","loadedFromSource":true,"saved":true,"sourceSize":{"x":349,"y":144},"rootRelativePath":"assets/v3/animations/COur4Yk9wN67PEowD8fbUzrmrNA6DDoR_Dft2qGzhHU/36f58a95-8579-4b60-8ca1-64255133a1f4.png"},"2bada650-7f0c-419f-9b28-24d2217c8cf6":{"name":"mg","sourceUrl":"assets/v3/animations/COur4Yk9wN67PEowD8fbUzrmrNA6DDoR_Dft2qGzhHU/2bada650-7f0c-419f-9b28-24d2217c8cf6.png","frameSize":{"x":250,"y":202},"frameCount":1,"looping":true,"frameDelay":4,"version":"Y4oqzw40BY.aZk0u7jt72XbN4z53Du1g","loadedFromSource":true,"saved":true,"sourceSize":{"x":250,"y":202},"rootRelativePath":"assets/v3/animations/COur4Yk9wN67PEowD8fbUzrmrNA6DDoR_Dft2qGzhHU/2bada650-7f0c-419f-9b28-24d2217c8cf6.png"},"ebcb7aa7-69ca-4869-8fff-5782fc2264b0":{"name":"gate","sourceUrl":"assets/v3/animations/COur4Yk9wN67PEowD8fbUzrmrNA6DDoR_Dft2qGzhHU/ebcb7aa7-69ca-4869-8fff-5782fc2264b0.png","frameSize":{"x":225,"y":225},"frameCount":1,"looping":true,"frameDelay":4,"version":"MR1_YRrGPJUYUWdGXiFKYG2lwE9K0x5c","loadedFromSource":true,"saved":true,"sourceSize":{"x":225,"y":225},"rootRelativePath":"assets/v3/animations/COur4Yk9wN67PEowD8fbUzrmrNA6DDoR_Dft2qGzhHU/ebcb7aa7-69ca-4869-8fff-5782fc2264b0.png"},"ca6699fc-18d2-4c30-a81c-1bfe4a2eb9a7":{"name":"alien","sourceUrl":"assets/v3/animations/COur4Yk9wN67PEowD8fbUzrmrNA6DDoR_Dft2qGzhHU/ca6699fc-18d2-4c30-a81c-1bfe4a2eb9a7.png","frameSize":{"x":353,"y":320},"frameCount":1,"looping":true,"frameDelay":4,"version":"D7m9b1yG4SunYl9kilZcfp.E0oYUBztU","loadedFromSource":true,"saved":true,"sourceSize":{"x":353,"y":320},"rootRelativePath":"assets/v3/animations/COur4Yk9wN67PEowD8fbUzrmrNA6DDoR_Dft2qGzhHU/ca6699fc-18d2-4c30-a81c-1bfe4a2eb9a7.png"},"cbb8a44d-46c1-4d9b-8b54-08ef261c3147":{"name":"ball","sourceUrl":"assets/v3/animations/COur4Yk9wN67PEowD8fbUzrmrNA6DDoR_Dft2qGzhHU/cbb8a44d-46c1-4d9b-8b54-08ef261c3147.png","frameSize":{"x":292,"y":292},"frameCount":1,"looping":true,"frameDelay":4,"version":"vzPffF_PEDb1AO0CFZKLSr_T73kZtjHj","loadedFromSource":true,"saved":true,"sourceSize":{"x":292,"y":292},"rootRelativePath":"assets/v3/animations/COur4Yk9wN67PEowD8fbUzrmrNA6DDoR_Dft2qGzhHU/cbb8a44d-46c1-4d9b-8b54-08ef261c3147.png"},"d561f458-aaa9-4858-8b54-4baa44b6a123":{"name":"robot","sourceUrl":"assets/api/v1/animation-library/gamelab/I9K_zCakC_DuV.ftWZYspgTeOGvnJuQY/category_characters/little_robot.png","frameSize":{"x":161,"y":300},"frameCount":1,"looping":true,"frameDelay":2,"version":"I9K_zCakC_DuV.ftWZYspgTeOGvnJuQY","categories":["characters"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":161,"y":300},"rootRelativePath":"assets/api/v1/animation-library/gamelab/I9K_zCakC_DuV.ftWZYspgTeOGvnJuQY/category_characters/little_robot.png"},"680a368f-d75b-471d-8afc-777140ac313e":{"name":"player","sourceUrl":null,"frameSize":{"x":204,"y":343},"frameCount":1,"looping":true,"frameDelay":12,"version":"HRrv0qxvzh7VghavOjNM_hKc54.xd.3p","categories":["characters"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":204,"y":343},"rootRelativePath":"assets/680a368f-d75b-471d-8afc-777140ac313e.png"},"12216abd-aa32-4566-8df7-e300430286c9":{"name":"demon","sourceUrl":null,"frameSize":{"x":269,"y":187},"frameCount":1,"looping":true,"frameDelay":12,"version":"cLI1L3UClrfeiQ4oBIPTrFkfrrxJSeo0","loadedFromSource":true,"saved":true,"sourceSize":{"x":269,"y":187},"rootRelativePath":"assets/12216abd-aa32-4566-8df7-e300430286c9.png"},"afbeb2a7-9a12-4fdb-adb7-7b22e7bceff4":{"name":"cave_1","sourceUrl":null,"frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":12,"version":"H__mlvBn4j0invUPupxgNwn_NvDOkbnY","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/afbeb2a7-9a12-4fdb-adb7-7b22e7bceff4.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var back=createSprite(200,600,1,1);
back.setAnimation("cave_1");

var gamestate='start';
var wall1=createSprite(600,100,400,10);
var wall2=createSprite(600,250,400,10);
var alien=createSprite(3440,350,10,10);
var laser1=createSprite(500,350,4,50);
var laser2=createSprite(600,300,4,50);
var laser3=createSprite(700,320,4,50);
var ball=createSprite(500,150,40,40);
var gate1=createSprite(3590,280,10,10);
var gate2=createSprite(5990,130,10,10);
var gate3=createSprite(3509,50,10,10);
gate3.setAnimation('mg');
gate3.scale=0.3;
var light1=createSprite(509,50,50,4);
var light2=createSprite(3009,30,50,4);
light1.shapeColor='gold';
light1.velocityX=7;
light2.shapeColor='gold';
light2.velocityX=-7;

gate1.setAnimation("gate");
gate1.scale=0.2;
gate2.setAnimation("gate");
gate2.scale=0.2;

ball.shapeColor='yellow';
laser1.shapeColor='red';
laser2.shapeColor='red';
laser3.shapeColor='red';

wall1.shapeColor='black';
wall2.shapeColor='black';
alien.setAnimation('alien');
alien.scale=0.1;
var atb=createSprite(250,200);
atb.setAnimation('atb');
atb.scale=0.4;
playSound("assets/category_background/repitition.mp3",true);


var ball2 = createSprite(2000,200,10,10);
ball2.setAnimation("ball");
var playerPaddle = createSprite(3800,200,10,70);
playerPaddle.setAnimation("player");
var computerPaddle = createSprite(1000,200,10,70);
computerPaddle.setAnimation("robot");
ball2.scale=0.1;
computerPaddle.scale=0.3;
playerPaddle.scale=0.3;
var gameState = "pause";
var playerScore = 0;


var cardboard1=createSprite(10,7000,100,15);
cardboard1.shapeColor="green";
var cardboard2=createSprite(140,4700,15,90);
cardboard2.shapeColor="green";
var cardboard3=createSprite(45,1700,90,15);
cardboard3.shapeColor="green";
var cardboard4=createSprite(90,1600,15,90);
cardboard4.shapeColor="green";
var cardboard5=createSprite(45,2700,15,100);
cardboard5.shapeColor="green";
var cardboard6=createSprite(80,3650,100,15);
cardboard6.shapeColor="green";
var cardboard7=createSprite(125,3650,15,100);
cardboard7.shapeColor="green";
var cardboard8=createSprite(101,2700,125,15);
cardboard8.shapeColor="green";
var cardboard9=createSprite(170,2800,15,130);
cardboard9.shapeColor="green";
var cardboard10=createSprite(222.5,3050,15,120);
cardboard10.shapeColor="green";
var cardboard11=createSprite(230,1600,15,130);
cardboard11.shapeColor="green";
var cardboard12=createSprite(205,2250,70,15);
cardboard12.shapeColor="green";
var cardboard13=createSprite(170,1900,15,90);
cardboard13.shapeColor="green";
var cardboard14=createSprite(280,850,15,100);
cardboard14.shapeColor="green";
var cardboard15=createSprite(295,4000,150,15);
cardboard15.shapeColor="green";
var cardboard16=createSprite(260,2900,90,15);
cardboard16.shapeColor="green";
var cardboard17=createSprite(340,1800,140,15);
cardboard17.shapeColor="green";
var cardboard18=createSprite(335,1100,15,140);
cardboard18.shapeColor="green";
var cardboard19=createSprite(275,2250,80,15);
cardboard19.shapeColor="green";
var cardboard20=createSprite(335,2250,45,15);
cardboard20.shapeColor="green";
var cardboard22=createSprite(297.5,3500,15,110);
cardboard22.shapeColor="green";
var cardboard23=createSprite(320,3050,55,15);
cardboard23.shapeColor="green";
var cardboard24=createSprite(340,3600,15,120);
cardboard24.shapeColor="green";
var cardboard25=createSprite(390,3800,15,50);
cardboard25.shapeColor="blue";
var man=createSprite(2000,280,15,15);
man.shapeColor="red";
var enemy=createSprite(120,10000,15,15);
enemy.shapeColor="yellow";
var enemy2=createSprite(200,20000,15,15);
enemy2.shapeColor="yellow";
var enemy3=createSprite(20,20000,15,15);
enemy3.shapeColor="yellow";
var enemy4=createSprite(250,15005,15,15);
enemy4.shapeColor="yellow";
var enemy5=createSprite(160,38005,15,15);
enemy5.shapeColor="yellow";
var enemy6=createSprite(375,22005,15,15);
enemy6.shapeColor="yellow";
var enemy7=createSprite(385,1000,15,15);
enemy7.shapeColor="yellow";
var enemy8=createSprite(260,27005,15,15);
enemy8.shapeColor="yellow";
var gameState2= "serve";


function draw() {
  
   background('green');
   if(ball2.isTouching(playerPaddle)) {
   playSound("assets/category_hits/puzzle_game_button_04.mp3");
   playerScore++;
   }
    if(ball2.isTouching(computerPaddle)) {
   playSound("assets/category_hits/puzzle_game_button_04.mp3");
   }
   
   createEdgeSprites();
    if(ball2.isTouching(topEdge)||ball2.isTouching(bottomEdge)){
  playSound("assets/category_hits/retro_game_simple_impact_1.mp3");
  }
  if(ball2.isTouching(rightEdge)){
    playSound("assets/category_explosion/radioactive_zombie_explode_2.mp3");
  }
   laser1.bounceOff(wall2);laser1.bounceOff(edges);laser2.bounceOff(wall2);laser2.bounceOff(edges);laser3.bounceOff(wall2);laser3.bounceOff(edges);ball.bounceOff(edges);ball.bounceOff(wall1);ball.bounceOff(wall2);light1.bounceOff(edges);light2.bounceOff(edges);alien.bounceOff(edges);alien.bounceOff(wall1);alien.bounceOff(wall2);
   ball2.bounceOff(topEdge);
   ball2.bounceOff(bottomEdge);
   ball2.bounceOff(playerPaddle);
   ball2.bounceOff(computerPaddle);
   playerPaddle.bounceOff(edges);
   man.bounceOff(edges);
    enemy.bounceOff(edges);
    enemy.bounceOff(cardboard8);
    enemy2.bounceOff(edges);
    enemy2.bounceOff(cardboard12);
    enemy3.bounceOff(edges);
    enemy3.bounceOff(cardboard3);
    enemy4.bounceOff(edges);
    enemy4.bounceOff(cardboard18);
    enemy4.bounceOff(cardboard11);
    enemy5.bounceOff(edges);
    enemy5.bounceOff(cardboard10);
    enemy5.bounceOff(cardboard7);
    enemy6.bounceOff(edges);
    enemy6.bounceOff(cardboard17);
    enemy7.bounceOff(edges);
    enemy7.bounceOff(cardboard24);
    enemy8.bounceOff(edges);
    enemy8.bounceOff(cardboard16);
    enemy8.bounceOff(cardboard19);
  
   if(gamestate==='start'){
    background('yellow');
    fill('red');
    textSize(25);
    text('There are three levels in the game.',10,100);
    text('Complete all the levels to WIN',10,150);
    text('All the Best',10,200);
    text('Press S to continue',100,300);
    }
    
   if(gamestate==='start'&&keyDown('s')){
      playSound("assets/category_male_voiceover/go_male.mp3");
      gamestate='serve1';
      atb.x=700;wall1.x=200;wall2.x=200;alien.x=30;laser1.x=100;laser2.x=200;laser3.x=300;light1.x=50;light2.x=3500;ball.x=100;gate1.x=350;gate2.x=50;gate3.x=350;ball.velocityX=8;ball.velocityY=8;laser1.velocityY=12;laser2.velocityY=12;laser3.velocityY=12;
      }
      if(gamestate==='serve1'){
      if(keyDown('right')){
    alien.x=alien.x+5;
   }
    if(keyDown('left')){
    alien.x=alien.x-5;
   }
    
   if(keyDown('up')){
    alien.y=alien.y-5;
   }
    
  
    if(keyDown('down')){
    alien.y=alien.y+5;
   }
      }
   if(alien.isTouching(laser1)||alien.isTouching(laser2)||alien.isTouching(laser3)||alien.isTouching(ball)||alien.isTouching(light1)||alien.isTouching(light2)){
   alien.x=30;
   alien.y=350;
   playSound("assets/category_explosion/vibrant_game_material_collect_3.mp3");
   }
   if(alien.isTouching(gate1)){
     alien.y=230;
     playSound("assets/category_achievements/lighthearted_bonus_objective_1.mp3");
   }
   if(alien.isTouching(gate2)){
     alien.y=80;
      playSound("assets/category_achievements/lighthearted_bonus_objective_1.mp3");
   }
   if(alien.isTouching(gate3)){
    laser1.velocityY=0;
    laser2.velocityY=0;
    laser3.velocityY=0;
    ball.velocityY=0;
    ball.velocityX=0;
    light1.velocityX=0;
    textSize(20);
    fill('yellow');
    text('Press N to continue to next level',50,320);
    gamestate='serve1end';
    }
    if(gamestate==='serve1end'&&keyDown('n')){
      gamestate='serve2';
      gameState='serve';
      wall1.x=2050;wall2.x=2500;alien.x=5350;laser1.x=1050;laser2.x=2050;laser3.x=3500;light1.x=550;light2.x=3500;ball.x=1050;gate1.x=5550;gate2.x=550;gate3.x=500;
      ball2.x=200;playerPaddle.x=380;computerPaddle.x=10;
      playSound("assets/category_male_voiceover/level_up_male.mp3");
    }
   
    

    if(gamestate==='serve2'){
    background('white');
    alien.x=1000;
    alien.y=1000;
    for(var i=0;i<400;i=i+20){
      line(200,i,200,i+10);
    }
      text('SCORE', 220,20);
      text(playerScore, 270,20);
    }
    
  
     if(gameState==='serve'){
     text('TARGET=20',170,150);
    text("Press Space to Serve",150,180);
    }
    
    computerPaddle.y = ball2.y;
    
  
    if (keyDown("space") &&  gameState === "serve") {
    serve();
    gameState = "play";
  }
  
    
    if(ball2.x > 400&&gamestate==='serve2') {
    playSound("score.mp3");
    reset();
    playerScore=0;
    gameState = "serve";
  }
  if (playerScore === 20){
    gameState = "over";
    reset();
    gamestate='serve2end';
    playSound("assets/category_achievements/lighthearted_bonus_objective_4.mp3");
  }
  if(gameState==='over'){
    fill("yellow");
    textSize(30);
    text("VICTORY",130,160);
    text("Press 'M' to continue",80,220);
    playerPaddle.x=1234;ball2.y=600;
    playerScore=0;
  }
  if(gamestate==='serve2'){
  if(keyDown("up")){
    playerPaddle.y=playerPaddle.y-5;
  }
   if(keyDown("down")){
    playerPaddle.y=playerPaddle.y+5;
  }
  }
  if(gamestate==='serve2end'&&keyDown('m')){
    gamestate='serve3';
    gameState='end';
    back.y=200;
    playSound("assets/category_male_voiceover/final_round_male.mp3");
    
  }
  drawSprites();
  if(gamestate==='serve3'){
  if (gameState2 === "serve") {
  man.x=30;man.y=20;enemy.x=120;enemy.y=10;enemy2.x=200;enemy2.y=200;enemy3.x=20;enemy3.y=200;enemy4.x=250;enemy4.y=155;enemy5.x=160;enemy5.y=360;enemy6.x=380;enemy6.y=225;enemy7.x=385;enemy7.y=310;enemy8.x=260;enemy8.y=275;
  cardboard1.y=70;cardboard2.y=47;cardboard3.y=170;cardboard4.y=160;cardboard5.y=270;cardboard6.y=365;cardboard7.y=365;cardboard8.y=270;cardboard9.y=280;cardboard10.y=350;cardboard11.y=160;cardboard12.y=225;cardboard13.y=190;cardboard14.y=85;cardboard15.y=40;cardboard16.y=290;cardboard17.y=180;cardboard18.y=110;cardboard19.y=225;cardboard20.y=225;
  cardboard22.y=350;cardboard23.y=305;cardboard24.y=360;cardboard25.y=380;
  
    fill("white");
    textSize("20");
    text("Press Space to Start",120,180);
    
  }
  if (keyDown("space") && gameState2 === "serve") {
    serve2();
    gameState2='play';
  }
  
    
  if(keyDown("left")){
   man.x=man.x-3;
    }
  
  if(keyDown("right")){
   man.x=man.x+3;
    }
    if(keyDown("up")){
   man.y=man.y-3;
    }
    if(keyDown("down")){
   man.y=man.y+3;
    }
  }
  if(man.isTouching(cardboard1)||man.isTouching(cardboard1)||man.isTouching(cardboard2)||man.isTouching(cardboard3)||man.isTouching(cardboard4)||man.isTouching(cardboard5)||man.isTouching(cardboard6)||man.isTouching(cardboard7)||man.isTouching(cardboard8)||man.isTouching(cardboard9)||man.isTouching(cardboard10)||
     man.isTouching(cardboard14)||man.isTouching(cardboard15)||man.isTouching(cardboard16)||man.isTouching(cardboard17)||man.isTouching(cardboard18)||man.isTouching(cardboard19)||man.isTouching(cardboard20)||man.isTouching(cardboard22)||man.isTouching(cardboard23)||man.isTouching(cardboard24)||man.isTouching(enemy)
     ||man.isTouching(enemy2)||man.isTouching(enemy3)||man.isTouching(cardboard11)||man.isTouching(cardboard12)||man.isTouching(cardboard13)||man.isTouching(enemy4)||man.isTouching(enemy5)||man.isTouching(enemy6)||man.isTouching(enemy7)||man.isTouching(enemy8)){
      man.x=20;
      man.y=30;
      reset2();
      gameState2="serve";
      playSound("assets/category_hits/retro_game_weapon_-_sword_on_shield_1.mp3");
    }
    
  if(man.isTouching(cardboard25)){
      reset2();
    gameState2="over";
    gamestate="serve3end";
    stopSound("assets/category_background/repitition.mp3");
    playSound("assets/category_male_voiceover/congratulations_male.mp3");
    man.x=10;man.y=10;
    
}
if(gamestate==='serve3end'){
  textSize(40);
    fill("yellow");
    stroke("blue");
    strokeWeight(5);
    text('YOU WON!!!!',100,200);
}
    
}
function serve() {
  ball2.velocityX = 11;
  ball2.velocityY = 12;
}

function reset() {
  ball2.x = 200;
  ball2.y = 200;
  ball2.velocityX = 0;
  ball2.velocityY = 0;
}
function serve2(){
  enemy.velocityY=15;
    enemy8.velocityY=4;
    enemy7.velocityX=3;
    enemy6.velocityY=7;
    enemy5.velocityX=3;
    enemy4.velocityX=7;
    enemy3.velocityY=4;
    enemy2.velocityY=17;
}
function reset2() {
  enemy.velocityY=0;
    enemy8.velocityY=0;
    enemy7.velocityX=0;
    enemy6.velocityY=0;
    enemy5.velocityX=0;
    enemy4.velocityX=0;
    enemy3.velocityY=0;
    enemy2.velocityY=0;
  
}
// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
